import re
import string


def PrintAll(): #prints out all items (once) and their quantites
    myjournal = open ('CS210_Project_Three_Input_File.txt')
    contents = myjournal.read()

    shopping = contents.split()
    shoppinglist = []
    for items in shopping:
        if items not in shoppinglist: #creates a list to get rid of duplicate names
            shoppinglist.append(items)

    for item in shoppinglist:
        print(item, shopping.count(item)) 

def ItemSearch(item): #searches for a specific item from a users input
    myjournal = open ('CS210_Project_Three_Input_File.txt')
    contents = myjournal.read()

    shopping = contents.split()
    return shopping.count(item)

def Writer(): #writes all items (once) and their quantites into a file
    mygrocery = open ('CS210_Project_Three_Input_File.txt')
    contents = mygrocery.read()
    file = open('frequency.dat', 'w')
    mygrocery.close()

    shopping = contents.split() #converts file contents into a list

    shoppinglist = []
    for items in shopping:
        if items not in shoppinglist: #creates a list to get rid of duplicate names
            shoppinglist.append(items)

    for item in shoppinglist: #writes items into the file
        file.write(item)
        file.write(' ')
        file.write(str(shopping.count(item)))
        file.write(' ')

    file.close()
    