#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("GrocerySort");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"GrocerySort");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"GrocerySort");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

int Menu() { //prints out menu and returns users input
	int input;

	cout << "1: Print out all items and frequency" << endl;
	cout << "2: Search for a specific item and frequency" << endl;
	cout << "3: Print out histogram for frequency of all items" << endl;
	cout << "4: Exit" << endl;

	cin >> input;
	return input;
}

void Histogram() {
	vector<string> items; //creates vector for items
	vector<int> quantities; //creates vector for quantites of items
	int i;
	int j;
	string item;
	int quantity;

	CallProcedure("Writer"); //calls python to write file used in method

	ifstream inFS;
	inFS.open("frequency.dat"); //opens file that was created in "Writer"
	if (!inFS.is_open()) {
		cout << "Could not open file." << endl;
	}

	while (!inFS.fail()) { //reads to end of file and puts both item and quantites into respective vectors
		inFS >> item;
		inFS >> quantity;
		items.push_back(item);
		quantities.push_back(quantity);
	}

	inFS.close();

	for (i = 0; i < items.size() - 1; i++) { // prints histogram for items
		cout << items.at(i);
		for (j = 0; j < quantities.at(i); j++) {
				cout << "*";
		}
		cout << endl;
	}
}

void FindItem() { //gets input from user and searches cart for item
	string userItem;
	cout << "Type item you wish to search for:";
	cin >> userItem;
	cout << "There are " << callIntFunc("ItemSearch", userItem) <<" " << userItem;
	cout << " in the cart" << endl;

}


int main()
{
	int userInput;
	userInput = 0;

	while (userInput != 4) {
		userInput = Menu();
		system("CLS");

		if (userInput == 4)
			break;

		switch (userInput) { //directs user option to correct menu feature
			case 1:
				CallProcedure("PrintAll");
				cout << endl;
				break;
			case 2:
				FindItem();
				break;
			case 3:
				Histogram();
				break;
			default:
				cout << "The option you chose was invalid, please choose an option from the menu "<< endl;
				break;
		}

		system("PAUSE");
		system("CLS");
	}
	return 0;
}